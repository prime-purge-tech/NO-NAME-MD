// commands/depo.js
import config from "../config.js";

const PHOTOS = [
  "https://jpcdn.it/img/5b19ed94906b19c243aa8a3a80981ac0.jpg",
  "https://jpcdn.it/img/fbf3582249f9a8cec80ae4f8dd41a02d.jpg",
  "https://jpcdn.it/img/d0530472742ca7315ca4bcbdc82d9d08.jpg",
  "https://jpcdn.it/img/af64e75962a6e4be9c2cb024df07574a.jpg",
  "https://jpcdn.it/img/455318e4c55150306c65c7bddb96aaed.jpg",
  "https://jpcdn.it/img/830eca607e68189062827af4c96f7669.jpg",
  "https://jpcdn.it/img/87b59ab199ed0f0ceb57de6ee1a2db2c.jpg",
  "https://jpcdn.it/img/270e8a194043c7a2b94045f4d6a0d5ff.jpg",
  "https://jpcdn.it/img/269bcadba7f1cd27d7b0a93a70ca14a4.jpg",
  "https://jpcdn.it/img/cf24e0ae14c5d88794aecf66d590c6c5.jpg",
  "https://jpcdn.it/img/d1c37576b24130d85aba67aaac413438.jpg",
  "https://jpcdn.it/img/0a36bf163ae91702817c448d489aaac2.jpg",
  "https://jpcdn.it/img/5ef376253ecdfbcee2f0487e67f780fe.jpg",
  "https://jpcdn.it/img/8cef95576060453375f3ba951a3c414d.jpg",
  "https://jpcdn.it/img/69eb14f201f27fc26fdb483cef3465d3.jpg",
  "https://jpcdn.it/img/10c0452317fd17d5b2823646e5ad0c02.jpg",
];

export default async function repoCommand(message, client) {
  const remoteJid = message.key.remoteJid;

  const photo = PHOTOS[Math.floor(Math.random() * PHOTOS.length)];

  const texte = `╭━━━〔 🚀 𝐑𝐄𝐏𝐎 〕━━━⬣
┃
┃  ⚡ *DÉPLOIE TON BOT EN 30 SEC*
┃
┣━━━〔 🔗 𝐋𝐈𝐄𝐍 𝐃𝐄 𝐂𝐎𝐍𝐍𝐄𝐗𝐈𝐎𝐍 〕━━━⬣
┃
┃  🌐 *Site Web :*
┃  http://panel.primeeedeath.site:3072
┃
┣━━━〔 📣 𝐑𝐄𝐒𝐄𝐀𝐔𝐗 〕━━━⬣
┃
┃  ✈️ *Telegram Dev :*
┃  https://t.me/dev_no_namee
┃
┃  ✈️ *Telegram Tech :*
┃  https://t.me/prime_purge_tech
┃
┃  📲 *WhatsApp Chaîne :*
┃  ${config.Channel}
┃
┣━━━〔 👑 𝐂𝐑𝐄𝐀𝐓𝐄𝐔𝐑 〕━━━⬣
┃
┃  🧠 *Owner :* @dev_no_name_off
┃  ⚡ *Bot :* ${config.BotName}
┃  💀 *Version :* 1.0.0
┃
┣━━━〔 📌 𝐌𝐎𝐃𝐄 𝐃'𝐄𝐌𝐏𝐋𝐎𝐈 〕━━━⬣
┃
┃  1️⃣ Ouvre le lien ci-dessus
┃  2️⃣ Entre ton numéro WhatsApp
┃  3️⃣ Saisis le code dans WhatsApp
┃  4️⃣ Ton bot est actif ! 🎉
┃
╰━━━〔 ⚡ *${config.BotName}* 〕━━━⬣
> _le pouvoir peut être avec toi si tu veux_.`;

  await client.sendMessage(remoteJid, {
    image: { url: photo },
    caption: texte
  }, { quoted: message });
}
