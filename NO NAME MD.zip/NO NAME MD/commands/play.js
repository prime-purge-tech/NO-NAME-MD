// commands/play.js
import config from "../config.js";
import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs";
import path from "path";
import os from "os";

const execAsync = promisify(exec);

// Lien chaîne à afficher sous chaque message
const VOIR_CHAINE = `\n> 🔗 *Voir la chaîne* : https://whatsapp.com/channel/0029VbABCDEFGHIJKLMNOP`;

export default async function playCommand(message, client, { args } = {}) {
  const remoteJid = message.key.remoteJid;

  try {
    const query = args && args.length > 0 ? args.join(" ") : null;

    if (!query) {
      return await client.sendMessage(remoteJid, {
        text: `╭━〔 🎵 𝐏𝐋𝐀𝐘 〕━⬣\n┃ ❌ Donne un titre à rechercher !\n┃ 📌 Ex: *.play Burna Boy*\n╰━━〔 ⚡ ${config.BotName} 〕━⬣${VOIR_CHAINE}`
      }, { quoted: message });
    }

    const msg1 = await client.sendMessage(remoteJid, {
      text: `╭━〔 🎵 𝐏𝐋𝐀𝐘 〕━⬣\n┃ 🔎 Recherche de *${query}* en cours...\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: message });

    await new Promise(r => setTimeout(r, 1500));
    await client.sendMessage(remoteJid, {
      text: `╭━〔 🎵 𝐏𝐋𝐀𝐘 〕━⬣\n┃ 📡 Connexion à la base musicale...\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: msg1 });

    await new Promise(r => setTimeout(r, 1500));
    await client.sendMessage(remoteJid, {
      text: `╭━〔 🎵 𝐏𝐋𝐀𝐘 〕━⬣\n┃ 🎶 Récupération des informations...\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: msg1 });

    // ─── Téléchargement via yt-dlp ───
    const tmpDir = os.tmpdir();
    const tmpFile = path.join(tmpDir, `play_${Date.now()}`);

    // Récupère les infos JSON d'abord
    let title = query, thumbnail = "", duration = "", views = "";
    try {
      const { stdout } = await execAsync(
        `yt-dlp "ytsearch1:${query.replace(/"/g, '')}" --dump-json --no-playlist --quiet`,
        { timeout: 30000 }
      );
      const info = JSON.parse(stdout.trim());
      title     = info.title     || query;
      thumbnail = info.thumbnail || "";
      duration  = info.duration_string || info.duration || "";
      views     = info.view_count ? Number(info.view_count).toLocaleString("fr-FR") : "";
    } catch (e) {
      console.log("⚠️ yt-dlp info:", e.message);
    }

    // Télécharge l'audio
    await execAsync(
      `yt-dlp "ytsearch1:${query.replace(/"/g, '')}" -x --audio-format mp3 --audio-quality 128K -o "${tmpFile}.%(ext)s" --no-playlist --quiet`,
      { timeout: 120000 }
    );

    // Trouve le fichier téléchargé
    const audioPath = `${tmpFile}.mp3`;
    if (!fs.existsSync(audioPath)) throw new Error("Fichier audio introuvable après téléchargement.");

    // ─── Vignette + infos ───
    const caption = `╭━〔 🎵 𝐏𝐋𝐀𝐘 〕━⬣
┃ 🎶 *${title}*
${duration ? `┃ ⏱️ Durée  : ${duration}\n` : ""}${views ? `┃ 👁️ Vues   : ${views}\n` : ""}┣━━〔 ⚡ ${config.BotName} 〕━⬣
┃ 👑 Dev : ${config.nameCreator}
╰━━━━━━━━━━━━━━━━━━━━⬣${VOIR_CHAINE}`;

    if (thumbnail) {
      await client.sendMessage(remoteJid, {
        image: { url: thumbnail },
        caption
      }, { quoted: message });
    } else {
      await client.sendMessage(remoteJid, { text: caption }, { quoted: message });
    }

    // ─── Envoi audio depuis fichier local ───
    const audioBuffer = fs.readFileSync(audioPath);
    await client.sendMessage(remoteJid, {
      audio: audioBuffer,
      mimetype: "audio/mpeg",
      ptt: false
    }, { quoted: message });

    // Nettoyage
    try { fs.unlinkSync(audioPath); } catch (_) {}

  } catch (err) {
    console.error("Erreur play:", err.message);
    await client.sendMessage(remoteJid, {
      text: `╭━〔 🎵 𝐏𝐋𝐀𝐘 〕━⬣\n┃ ⚠️ Échec : ${err.message}\n╰━━〔 ⚡ ${config.BotName} 〕━⬣${VOIR_CHAINE}`
    }, { quoted: message });
  }
}
