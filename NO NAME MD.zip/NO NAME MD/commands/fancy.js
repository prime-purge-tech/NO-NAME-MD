const scriptMap = {
  a: '𝒶', b: '𝒷', c: '𝒸', d: '𝒹', e: '𝑒', f: '𝒻', g: '𝑔', h: '𝒽', i: '𝒾', j: '𝒿',
  k: '𝓀', l: '𝓁', m: '𝓂', n: '𝓃', o: '𝑜', p: '𝓅', q: '𝓆', r: '𝓇', s: '𝓈', t: '𝓉',
  u: '𝓊', v: '𝓋', w: '𝓌', x: '𝓍', y: '𝓎', z: '𝓏',
  A: '𝒜', B: '𝐵', C: '𝒞', D: '𝒟', E: '𝐸', F: '𝐹', G: '𝒢', H: '𝐻', I: '𝐼', J: '𝒥',
  K: '𝒦', L: '𝐿', M: '𝑀', N: '𝒩', O: '𝒪', P: '𝒫', Q: '𝒬', R: '𝑅', S: '𝒮', T: '𝒯',
  U: '𝒰', V: '𝒱', W: '𝒲', X: '𝒳', Y: '𝒴', Z: '𝒵'
};

const frakturMap = {
  A: '𝔄', B: '𝔅', C: 'ℭ', D: '𝔇', E: '𝔈', F: '𝔉', G: '𝔊', H: 'ℌ', I: 'ℑ', J: '𝔍',
  K: '𝔎', L: '𝔏', M: '𝔐', N: '𝔑', O: '𝔒', P: '𝔓', Q: '𝔔', R: 'ℜ', S: '𝔖', T: '𝔗',
  U: '𝔘', V: '𝔙', W: '𝔚', X: '𝔛', Y: '𝔜', Z: 'ℨ',
  a: '𝔞', b: '𝔟', c: '𝔠', d: '𝔡', e: '𝔢', f: '𝔣', g: '𝔤', h: '𝔥', i: '𝔦', j: '𝔧',
  k: '𝔨', l: '𝔩', m: '𝔪', n: '𝔫', o: '𝔬', p: '𝔭', q: '𝔮', r: '𝔯', s: '𝔰', t: '𝔱',
  u: '𝔲', v: '𝔳', w: '𝔴', x: '𝔵', y: '𝔶', z: '𝔷'
};

const doubleStruckMap = {
  A: '𝔸', B: '𝔹', C: 'ℂ', D: '𝔻', E: '𝔼', F: '𝔽', G: '𝔾', H: 'ℍ', I: '𝕀', J: '𝕁',
  K: '𝕂', L: '𝕃', M: '𝕄', N: 'ℕ', O: '𝕆', P: 'ℙ', Q: 'ℚ', R: 'ℝ', S: '𝕊', T: '𝕋',
  U: '𝕌', V: '𝕍', W: '𝕎', X: '𝕏', Y: '𝕐', Z: 'ℤ',
  a: '𝕒', b: '𝕓', c: '𝕔', d: '𝕕', e: '𝕖', f: '𝕗', g: '𝕘', h: '𝕙', i: '𝕚', j: '𝕛',
  k: '𝕜', l: '𝕝', m: '𝕞', n: '𝕟', o: '𝕠', p: '𝕡', q: '𝕢', r: '𝕣', s: '𝕤', t: '𝕥',
  u: '𝕦', v: '𝕧', w: '𝕨', x: '𝕩', y: '𝕪', z: '𝕫'
};

const monospaceMap = {
  a: '𝚊', b: '𝚋', c: '𝚌', d: '𝚍', e: '𝚎', f: '𝚏', g: '𝚐', h: '𝚑', i: '𝚒', j: '𝚓',
  k: '𝚔', l: '𝚕', m: '𝚖', n: '𝚗', o: '𝚘', p: '𝚙', q: '𝚚', r: '𝚛', s: '𝚜', t: '𝚝',
  u: '𝚞', v: '𝚟', w: '𝚠', x: '𝚡', y: '𝚢', z: '𝚣',
  A: '𝙰', B: '𝙱', C: '𝙲', D: '𝙳', E: '𝙴', F: '𝙵', G: '𝙶', H: '𝙷', I: '𝙸', J: '𝙹',
  K: '𝙺', L: '𝙻', M: '𝙼', N: '𝙽', O: '𝙾', P: '𝙿', Q: '𝚀', R: '𝚁', S: '𝚂', T: '𝚃',
  U: '𝚄', V: '𝚅', W: '𝚆', X: '𝚇', Y: '𝚈', Z: '𝚉'
};

const squaredMap = {
  A: '🄰', B: '🄱', C: '🄲', D: '🄳', E: '🄴', F: '🄵', G: '🄶', H: '🄷', I: '🄸', J: '🄹',
  K: '🄺', L: '🄻', M: '🄼', N: '🄽', O: '🄾', P: '🄿', Q: '🅀', R: '🅁', S: '🅂', T: '🅃',
  U: '🅄', V: '🅅', W: '🅆', X: '🅇', Y: '🅈', Z: '🅉'
};

const circledMap = {
  a: 'ⓐ', b: 'ⓑ', c: 'ⓒ', d: 'ⓓ', e: 'ⓔ', f: 'ⓕ', g: 'ⓖ', h: 'ⓗ', i: 'ⓘ', j: 'ⓙ',
  k: 'ⓚ', l: 'ⓛ', m: 'ⓜ', n: 'ⓝ', o: 'ⓞ', p: 'ⓟ', q: 'ⓠ', r: 'ⓡ', s: 'ⓢ', t: 'ⓣ',
  u: 'ⓤ', v: 'ⓥ', w: 'ⓦ', x: 'ⓧ', y: 'ⓨ', z: 'ⓩ'
};

const convertMap = (map) => (t) => [...t].map(c => map[c] || c).join('');

const fancyFonts = [
  (t) => t,
  (t) => t.toUpperCase(),
  (t) => t.toLowerCase(),
  convertMap(scriptMap),
  convertMap(doubleStruckMap),
  convertMap(frakturMap),
  convertMap(monospaceMap),
  convertMap(squaredMap),
  convertMap(circledMap),
  (t) => [...t].map(c => `${c}̷`).join(''),
  (t) => [...t].map(c => `${c}͎`).join(''),
  (t) => `✨ ${t} ✨`,
  (t) => `🔥 ${t.toUpperCase()} 🔥`,
  (t) => `👑 ${t} 👑`,
  (t) => `༒ ${t} ༒`,
  (t) => `★彡 ${t} 彡★`,
  (t) => `✧･ﾟ: *✧･ﾟ:* ${t} *:･ﾟ✧*:･ﾟ✧`,
  (t) => t.split('').join(' '),
  (t) => [...t].map(c => `(${c})`).join(''),
  (t) => `「${t}」`,
  (t) => `『★${t}★』`
];

export async function fancyCommand(message, client) {
  const remoteJid = message.key.remoteJid;
  const text = message.message?.extendedTextMessage?.text || message.message?.conversation || '';
  const parts = text.trim().split(/s+/);
  const args = parts.slice(1);

  if (args.length === 0) {
    const sampleText = 'オビト・デヴ卿';
    const preview = fancyFonts.map((f, i) => `*${i + 1}.* ${f(sampleText)}`).join('

');
    return await client.sendMessage(remoteJid, { text: preview });
  }

  const styleIndex = parseInt(args[0], 10) - 1;
  const content = args.slice(1).join(' ');

  if (Number.isNaN(styleIndex) || styleIndex < 0 || styleIndex >= fancyFonts.length) {
    const sampleText = args.join(' ');
    if (sampleText) {
      const preview = fancyFonts.map((f, i) => `*${i + 1}.* ${f(sampleText)}`).join('

');
      return await client.sendMessage(remoteJid, { text: preview });
    }
    return await client.sendMessage(remoteJid, {
      text: `❌ Invalid style number. Use *.fancy* to view styles.`
    });
  }

  if (!content.trim()) {
    return await client.sendMessage(remoteJid, {
      text: `⚠️ Please provide text to style.
Example: *.fancy 3 Hello World!*`
    });
  }

  const styled = fancyFonts[styleIndex](content);
  return await client.sendMessage(remoteJid, { text: styled });
}

export default fancyCommand;