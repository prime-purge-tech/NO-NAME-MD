// commands/menu.js
import config from "../config.js";
import { getThemePhoto, getThemeEmoji, THEMES, groupThemes } from "./theme.js";

export default async function menuCommand(message, client) {
  try {
    const remoteJid = message.key.remoteJid;
    const themeName = groupThemes.get(remoteJid) || "yuta";
    const theme = THEMES[themeName];
    const photo = getThemePhoto(remoteJid);
    const emoji = theme?.emoji || "⚡";

    const menuText = `╭━〔 ${emoji} 𝐍𝐎 𝐍𝐀𝐌𝐄 𝐌𝐃 〕━⬣
┃ 📛 𝗕𝗼𝘁     : NO NAME MD
┃ 👑 𝗗𝗲𝘃     : PRIME PURGE
┃ 📌 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : 1.0.0
┃ 🎨 𝗧𝗵è𝗺𝗲  : ${theme?.nom || "Yuta"}
┣━━〔 🎮 𝗝𝗘𝗨𝗫 〕━⬣
┃ ❏ .quiz
┃ ❏ .manga
┃ ❏ .kamui
┣━━〔 🎵 𝗠𝗘𝗗𝗜𝗔 〕━⬣
┃ ❏ .play
┃ ❏ .tts
┃ ❏ .vv
┃ ❏ .s
┣━━〔 🤖𝗜𝗡𝗧𝗘𝗟𝗟𝗜𝗚𝗘𝗡𝗖𝗘 〕━⬣
┃ ❏ .ai
┃ ❏ .automsg
┣━━〔 🛡️ 𝗚𝗥𝗢𝗨𝗣𝗘 〕━⬣
┃ ❏ .antilink
┃ ❏ .antidemote
┃ ❏ .welcome
┃ ❏ .goodbye
┣━━〔 👮 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗧𝗜𝗢𝗡 〕━⬣
┃ ❏ .kick
┃ ❏ .kickall
┃ ❏ .mute
┃ ❏ .unmute
┃ ❏ .promote
┃ ❏ .demote
┃ ❏ .demoteall
┃ ❏ .tag
┃ ❏ .tagall
┣━━〔 🔧 𝗢𝗨𝗧𝗜𝗟𝗦 〕━⬣
┃ ❏ .ping
┃ ❏ .fancy
┃ ❏ .pair
┃ ❏ .channel
┃ ❏ .repo
┃ ❏ .theme
┃ ❏ .menu
┣━━〔 😈 𝗡𝗢 𝗡𝗔𝗠𝗘 〕━⬣
┃ ❏ .no
┃ ❏ .noname
┣━━〔 📞 𝗖𝗢𝗡𝗧𝗔𝗖𝗧 〕━⬣
┃ ✈️ t.me/dev_no_namee
┃ ✈️ t.me/prime_purge_tech
┃ 👤 @dev_no_name_off
╰━━〔 ${emoji} 𝐍𝐎 𝐍𝐀𝐌𝐄 𝐌𝐃 〕━⬣
> ${config.nameCreator}
> 🔗 Voir la chaîne : ${config.Channel}`;

    await client.sendMessage(remoteJid, {
      image: { url: photo },
      caption: menuText
    }, { quoted: message });

    await client.sendMessage(remoteJid, {
      audio: { url: "https://files.catbox.moe/yv595u.m4a" },
      mimetype: "audio/mpeg",
      ptt: true
    });

  } catch (err) {
    console.error("Erreur menuCommand:", err.message);
  }
}
