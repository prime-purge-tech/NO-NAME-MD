// commands/antidemote.js - Anti-demote avec auto-rétrogradation
import config from "../config.js";

// Stockage des actions récentes (10 minutes)
const recentActions = new Map(); // key: groupJid, value: Map { demoteur => {time, target} }

// Photos aléatoires
const PHOTOS = [
  "https://jpcdn.it/img/5b19ed94906b19c243aa8a3a80981ac0.jpg",
  "https://jpcdn.it/img/fbf3582249f9a8cec80ae4f8dd41a02d.jpg",
  "https://jpcdn.it/img/d0530472742ca7315ca4bcbdc82d9d08.jpg",
  "https://jpcdn.it/img/af64e75962a6e4be9c2cb024df07574a.jpg",
  "https://jpcdn.it/img/455318e4c55150306c65c7bddb96aaed.jpg",
  "https://jpcdn.it/img/830eca607e68189062827af4c96f7669.jpg",
  "https://jpcdn.it/img/87b59ab199ed0f0ceb57de6ee1a2db2c.jpg",
  "https://jpcdn.it/img/270e8a194043c7a2b94045f4d6a0d5ff.jpg",
  "https://jpcdn.it/img/269bcadba7f1cd27d7b0a93a70ca14a4.jpg",
  "https://jpcdn.it/img/cf24e0ae14c5d88794aecf66d590c6c5.jpg",
  "https://jpcdn.it/img/d1c37576b24130d85aba67aaac413438.jpg",
  "https://jpcdn.it/img/0a36bf163ae91702817c448d489aaac2.jpg",
  "https://jpcdn.it/img/5ef376253ecdfbcee2f0487e67f780fe.jpg",
  "https://jpcdn.it/img/8cef95576060453375f3ba951a3c414d.jpg",
  "https://jpcdn.it/img/69eb14f201f27fc26fdb483cef3465d3.jpg",
  "https://jpcdn.it/img/10c0452317fd17d5b2823646e5ad0c02.jpg",
];

function photoAleatoire() {
  return PHOTOS[Math.floor(Math.random() * PHOTOS.length)];
}

function getNumero(jid = "") {
  return jid.replace(/@.+/, "").replace(/:.*/, "").trim();
}

function bold(text) {
  return `*${text}*`;
}

// Nettoyer les actions anciennes (plus de 10 minutes)
function cleanOldActions(groupJid) {
  const tenMinutesAgo = Date.now() - 10 * 60 * 1000;
  const groupActions = recentActions.get(groupJid);
  if (!groupActions) return;
  
  for (const [demoteur, data] of groupActions) {
    if (data.time < tenMinutesAgo) {
      groupActions.delete(demoteur);
    }
  }
  
  if (groupActions.size === 0) {
    recentActions.delete(groupJid);
  }
}

// Enregistrer une action de démotion
function enregistrerAction(groupJid, demoteur, target) {
  if (!recentActions.has(groupJid)) {
    recentActions.set(groupJid, new Map());
  }
  const groupActions = recentActions.get(groupJid);
  groupActions.set(demoteur, {
    time: Date.now(),
    target: target
  });
  cleanOldActions(groupJid);
}

// Récupérer tous les démoteurs récents
function getRecentDemoteurs(groupJid) {
  cleanOldActions(groupJid);
  const groupActions = recentActions.get(groupJid);
  if (!groupActions) return [];
  return Array.from(groupActions.keys());
}

// Rétrograder quelqu'un
async function demotePerson(client, groupJid, targetJid, raison) {
  try {
    await client.groupParticipantsUpdate(groupJid, [targetJid], "demote");
    console.log(`✅ Rétrogradé: ${targetJid} (${raison})`);
    return true;
  } catch (err) {
    console.log(`❌ Échec rétrogradation ${targetJid}:`, err.message);
    return false;
  }
}

// Renommer quelqu'un (changer son nom dans le groupe)
async function renamePerson(client, groupJid, targetJid, nouveauNom) {
  try {
    await client.groupParticipantsUpdate(groupJid, [targetJid], "demote");
    // WhatsApp ne permet pas de renommer directement, on envoie un message tag
    return false;
  } catch (err) {
    return false;
  }
}

// ─── Groupes où l'anti-demote est actif ───
export const antiDemoteGroups = new Map();

// ─── Commande .antidemote on/off ───
export default async function antidemoteCommand(message, client, { args } = {}) {
  const remoteJid = message.key.remoteJid;

  if (!remoteJid.endsWith("@g.us")) {
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🛡️ 𝐀𝐍𝐓𝐈𝐃𝐄𝐌𝐎𝐓𝐄 〕━⬣\n┃ ❌ Uniquement dans un groupe !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    });
  }

  const meta = await client.groupMetadata(remoteJid);
  const senderJidBrut = message.key.participant || message.key.remoteJid;
  const senderNumero = getNumero(senderJidBrut);
  const senderInfo = meta.participants.find(p => getNumero(p.id) === senderNumero);
  const estAdmin = senderInfo?.admin === "admin" || senderInfo?.admin === "superadmin";

  if (!estAdmin) {
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🛡️ 𝐀𝐍𝐓𝐈𝐃𝐄𝐌𝐎𝐓𝐄 〕━⬣\n┃ ❌ Réservé aux *admins du groupe* !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    });
  }

  const option = args[0]?.toLowerCase();

  if (option === "on") {
    antiDemoteGroups.set(remoteJid, true);
    const photo = photoAleatoire();
    await client.sendMessage(remoteJid, {
      image: { url: photo },
      caption: `╭━〔 🛡️ 𝐀𝐍𝐓𝐈𝐃𝐄𝐌𝐎𝐓𝐄 〕━⬣
┃ 
┃ ✅ Anti-demote *ACTIVÉ* !
┃ 
┃ 🔒 Protection activée :
┃ • Toute dénomination sera détectée
┃ • Le coupable sera dénommé
┃ • Tag de tous les membres
┃ • Photo aléatoire
┃ 
╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    });
  } else if (option === "off") {
    antiDemoteGroups.delete(remoteJid);
    recentActions.delete(remoteJid);
    const photo = photoAleatoire();
    await client.sendMessage(remoteJid, {
      image: { url: photo },
      caption: `╭━〔 🛡️ 𝐀𝐍𝐓𝐈𝐃𝐄𝐌𝐎𝐓𝐄 〕━⬣
┃ 
┃ ❌ Anti-demote *DÉSACTIVÉ*
┃ 
╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    });
  } else if (option === "punish") {
    // Commande pour punir tous les démoteurs récents
    const demoteurs = getRecentDemoteurs(remoteJid);
    
    if (demoteurs.length === 0) {
      await client.sendMessage(remoteJid, {
        text: `╭━〔 🛡️ 𝐀𝐍𝐓𝐈𝐃𝐄𝐌𝐎𝐓𝐄 〕━⬣
┃ 
┃ ⚠️ Aucun démoteur trouvé
┃ dans les 10 dernières minutes !
┃ 
╰━━〔 ⚡ ${config.BotName} 〕━⬣`
      });
      return;
    }
    
    const photo = photoAleatoire();
    let listeDemoteurs = "";
    for (const d of demoteurs) {
      listeDemoteurs += `┃ 🤡 @${d}\n`;
    }
    
    await client.sendMessage(remoteJid, {
      image: { url: photo },
      caption: `╭━〔 🩸 CHÂTIMENT DES DÉMOTEURS 〕━⬣
┃ 
┃ 🔴 ${demoteurs.length} personne(s) à punir :
┃ 
${listeDemoteurs}
┃ ⚡ Rétrogradation en cours...
┃ 
╰━━〔 ⚡ ${config.BotName} 〕━⬣`,
      mentions: demoteurs.map(d => `${d}@s.whatsapp.net`)
    });
    
    let succes = 0;
    for (const demoteur of demoteurs) {
      const demoteurJid = `${demoteur}@s.whatsapp.net`;
      const resultat = await demotePerson(client, remoteJid, demoteurJid, "a dénommé quelqu'un");
      if (resultat) succes++;
      await delay(1000);
    }
    
    await client.sendMessage(remoteJid, {
      text: `╭━〔 ✅ CHÂTIMENT TERMINÉ 〕━⬣
┃ 
┃ ✅ ${succes}/${demoteurs.length} démoteurs rétrogradés
┃ 
╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    });
    
    recentActions.delete(remoteJid);
    
  } else {
    const statut = antiDemoteGroups.has(remoteJid) ? "✅ ACTIVÉ" : "❌ DÉSACTIVÉ";
    const photo = photoAleatoire();
    await client.sendMessage(remoteJid, {
      image: { url: photo },
      caption: `╭━〔 🛡️ 𝐀𝐍𝐓𝐈𝐃𝐄𝐌𝐎𝐓𝐄 〕━⬣
┃ 
┃ 📊 Statut : *${statut}*
┃ 
┃ 📌 *.antidemote on* → Activer
┃ 📌 *.antidemote off* → Désactiver
┃ 📌 *.antidemote punish* → Punir les démoteurs (10min)
┃ 
╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    });
  }
}

// ─── Handler appelé depuis handler.js ───
export async function handleAntiDemote(groupJid, promoter, demotedList, client) {
  if (!antiDemoteGroups.has(groupJid)) return;

  try {
    const meta = await client.groupMetadata(groupJid);
    const botNumero = getNumero(client.user.id);
    const promoterNumero = getNumero(promoter);
    
    // Enregistrer l'action du démoteur
    for (const demotedJid of demotedList) {
      const demotedNumero = getNumero(demotedJid);
      enregistrerAction(groupJid, promoterNumero, demotedNumero);
    }

    // Tous les membres pour le tagall
    const tousLesMembres = meta.participants.map(p => p.id);
    const tagallText = tousLesMembres.map(j => `@${getNumero(j)}`).join(" ");
    const photo = photoAleatoire();

    for (const demotedJid of demotedList) {
      const demotedNumero = getNumero(demotedJid);
      const estBot = demotedNumero === botNumero;

      if (estBot) {
        // ─── Le bot a été dénommé → tagall + expulse le coupable + rétrograde ses complices ───
        
        // Rétrograder tous les démoteurs récents
        const demoteursRecents = getRecentDemoteurs(groupJid);
        for (const dem of demoteursRecents) {
          if (dem !== promoterNumero) {
            await demotePerson(client, groupJid, `${dem}@s.whatsapp.net`, "complice de dénomination");
            await delay(1000);
          }
        }
        
        // Rétrograder le coupable aussi
        await demotePerson(client, groupJid, promoter, "a dénommé le bot");
        await delay(1000);
        
        // Envoyer le message avec photo
        await client.sendMessage(groupJid, {
          image: { url: photo },
          caption: `╭━〔 🩸 VOL DE GROUPE DÉTECTÉ 〕━⬣
┃ 
┃ ${tagallText}
┃ 
┃ 🤡 @${promoterNumero} a essayé de dénommer le bot !
┃ 
┃ ⚡ *Sanctions :*
┃ • @${promoterNumero} a été dénommé(e)
┃ • Ses complices ont été dénommé(e)s
┃ 
┃ 🛡️ *${config.BotName}* — PROTECTION TOTALE
┃ 👑 Dev : ${config.nameCreator}
┃ 
╰━━〔 ⚡ ${config.BotName} 〕━⬣`,
          mentions: tousLesMembres
        });

        await delay(2000);

        try {
          await client.groupParticipantsUpdate(groupJid, [promoter], "remove");
          console.log(`✅ Expulsé (a dénommé le bot) : ${promoter}`);
          await client.sendMessage(groupJid, {
            text: `🚪 @${promoterNumero} a été expulsé du groupe !`,
            mentions: [promoter]
          });
        } catch (e) {
          console.log("❌ Impossible d'expulser :", e.message);
        }

      } else {
        // ─── Un admin a été dénommé → re-promu + dénonce + rétrograde le coupable ───
        
        // Re-promouvoir l'admin dénommé
        try {
          await client.groupParticipantsUpdate(groupJid, [demotedJid], "promote");
          console.log(`✅ Re-promu : ${demotedJid}`);
        } catch (e) {
          console.log("❌ Impossible de re-promouvoir :", e.message);
        }
        
        // Rétrograder le coupable
        await demotePerson(client, groupJid, promoter, "a dénommé un admin");
        await delay(1000);
        
        // Envoyer le message avec photo
        await client.sendMessage(groupJid, {
          image: { url: photo },
          caption: `╭━〔 🩸 PURGEUR DÉTECTÉ 〕━⬣
┃ 
┃ 🤡 @${promoterNumero} a essayé de dénommer @${demotedNumero}
┃ 
┃ ⚡ *Sanctions :*
┃ • @${promoterNumero} a été dénommé(e)
┃ • @${demotedNumero} a été re-promu(e)
┃ 
┃ 🛡️ *${config.BotName}* — PROTECTION ACTIVE
┃ 👑 Dev : ${config.nameCreator}
┃ 
╰━━〔 ⚡ ${config.BotName} 〕━⬣`,
          mentions: [promoter, demotedJid]
        });
      }
    }
  } catch (err) {
    console.error("Erreur handleAntiDemote:", err.message);
  }
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}