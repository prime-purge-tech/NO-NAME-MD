// commands/antilink.js
import config from "../config.js";

// ─── Modes : "off" | "on" | "war" ───
// "on"  = supprime le message + avertissement
// "war" = supprime + expulse directement
export const antilinkGroups = new Map(); // groupJid → "on" | "war"

function getNumero(jid = "") {
  return jid.replace(/@.+/, "").replace(/:.*/, "").trim();
}

// ─── Détection de liens ───
function contiensLien(texte = "") {
  const regex = /(?:https?:\/\/|www\.|chat\.whatsapp\.com|t\.me\/|bit\.ly|tinyurl|youtu\.be|discord\.gg)[^\s]*/gi;
  return regex.test(texte);
}

// ─── Commande .antilink on/off/war ───
export default async function antilinkCommand(message, client, { args } = {}) {
  const remoteJid = message.key.remoteJid;

  if (!remoteJid.endsWith("@g.us")) {
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🔗 𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊 〕━⬣\n┃ ❌ Uniquement dans un groupe !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: message });
  }

  // Vérif admin
  const meta = await client.groupMetadata(remoteJid);
  const senderJid = message.key.participant || message.key.remoteJid;
  const senderNumero = getNumero(senderJid);
  const senderInfo = meta.participants.find(p => getNumero(p.id) === senderNumero);
  const estAdmin = senderInfo?.admin === "admin" || senderInfo?.admin === "superadmin";

  if (!estAdmin) {
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🔗 𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊 〕━⬣\n┃ ❌ Réservé aux *admins du groupe* !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: message });
  }

  const option = args[0]?.toLowerCase();

  if (option === "on") {
    antilinkGroups.set(remoteJid, "on");
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🔗 𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊 〕━⬣\n┃ ✅ Anti-lien *ACTIVÉ* !\n┃ 🚫 Les liens seront supprimés\n┃ ⚠️ + avertissement envoyé\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: message });

  } else if (option === "war") {
    antilinkGroups.set(remoteJid, "war");
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🔗 𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊 〕━⬣\n┃ ⚔️ Mode *WAR ACTIVÉ* !\n┃ 💀 Tout lien = expulsion directe\n┃ 🚫 Aucun avertissement !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: message });

  } else if (option === "off") {
    antilinkGroups.delete(remoteJid);
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🔗 𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊 〕━⬣\n┃ ❌ Anti-lien *DÉSACTIVÉ*\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: message });

  } else {
    const mode = antilinkGroups.get(remoteJid);
    const statut = !mode ? "❌ DÉSACTIVÉ" : mode === "war" ? "⚔️ WAR" : "✅ ON";
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🔗 𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊 〕━⬣\n┃ 📊 Mode actuel : *${statut}*\n┣━━━━━━━━━━━━━━━━━━━━⬣\n┃ 📌 *.antilink on* → supprime le lien\n┃ 📌 *.antilink war* → supprime + expulse\n┃ 📌 *.antilink off* → désactiver\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`
    }, { quoted: message });
  }
}

// ─── Handler appelé depuis handler.js sur chaque message ───
export async function handleAntiLink(message, client) {
  const remoteJid = message.key.remoteJid;

  if (!remoteJid.endsWith("@g.us")) return;

  const mode = antilinkGroups.get(remoteJid);
  if (!mode) return;

  // Récupère le texte du message
  const texte =
    message.message?.conversation ||
    message.message?.extendedTextMessage?.text ||
    message.message?.imageMessage?.caption ||
    message.message?.videoMessage?.caption ||
    "";

  if (!contiensLien(texte)) return;

  // Infos expéditeur
  const senderJid = message.key.participant || message.key.remoteJid;
  if (message.key.fromMe) return; // Ignore les messages du bot lui-même

  const senderNumero = getNumero(senderJid);

  try {
    const meta = await client.groupMetadata(remoteJid);
    const botNumero = getNumero(client.user.id);

    // Ignore si l'expéditeur est admin
    const senderInfo = meta.participants.find(p => getNumero(p.id) === senderNumero);
    const estAdmin = senderInfo?.admin === "admin" || senderInfo?.admin === "superadmin";
    if (estAdmin) return;

    // ─── Supprime le message ───
    try {
      await client.sendMessage(remoteJid, {
        delete: message.key
      });
    } catch (e) {
      console.log("❌ Impossible de supprimer le message:", e.message);
    }

    if (mode === "on") {
      // ─── Mode ON : avertissement ───
      await client.sendMessage(remoteJid, {
        text: `╭━〔 🔗 𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊 〕━⬣\n┃ ⚠️ @${senderNumero} !\n┃ 🚫 Les liens sont *interdits* ici !\n┃ 📌 Prochaine fois = expulsion !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`,
        mentions: [senderJid]
      });

    } else if (mode === "war") {
      // ─── Mode WAR : expulsion directe ───
      await client.sendMessage(remoteJid, {
        text: `╭━〔 ⚔️ 𝐖𝐀𝐑 𝐌𝐎𝐃𝐄 〕━⬣\n┃ 💀 @${senderNumero} *EXPULSÉ* !\n┃ 🔗 Lien envoyé = sortie directe !\n┃ 🚫 Aucun avertissement ici !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣`,
        mentions: [senderJid]
      });

      await new Promise(r => setTimeout(r, 500));

      try {
        await client.groupParticipantsUpdate(remoteJid, [senderJid], "remove");
        console.log(`✅ Expulsé (lien en mode war) : ${senderJid}`);
      } catch (e) {
        console.log("❌ Impossible d'expulser:", e.message);
      }
    }

  } catch (err) {
    console.error("Erreur handleAntiLink:", err.message);
  }
}
