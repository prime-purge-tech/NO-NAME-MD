// commands/mute.js
import config from "../config.js";

function getNumero(jid = "") {
  return jid.replace(/@.+/, "").replace(/:.*/, "").trim();
}

export default async function muteCommand(message, client) {
  const remoteJid = message.key.remoteJid;

  if (!remoteJid.endsWith("@g.us")) {
    return await client.sendMessage(remoteJid, {
      text: `╭━〔 🔇 𝐌𝐔𝐓𝐄 〕━⬣\n┃ ❌ Uniquement dans un groupe !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣\n> 🔗 Voir la chaîne : ${config.Channel}`
    }, { quoted: message });
  }

  try {
    const meta = await client.groupMetadata(remoteJid);
    const senderJid = message.key.participant || message.key.remoteJid;
    const senderNumero = getNumero(senderJid);
    const senderInfo = meta.participants.find(p => getNumero(p.id) === senderNumero);
    const estAdmin = senderInfo?.admin === "admin" || senderInfo?.admin === "superadmin";

    if (!estAdmin) {
      return await client.sendMessage(remoteJid, {
        text: `╭━〔 🔇 𝐌𝐔𝐓𝐄 〕━⬣\n┃ ❌ Réservé aux *admins du groupe* !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣\n> 🔗 Voir la chaîne : ${config.Channel}`
      }, { quoted: message });
    }

    // Passe en mode "admins seulement"
    await client.groupSettingUpdate(remoteJid, "announcement");

    await client.sendMessage(remoteJid, {
      text: `╭━〔 🔇 𝐌𝐔𝐓𝐄 〕━⬣\n┃ ✅ Groupe *muté* !\n┃ 🔒 Seuls les admins peuvent écrire\n┃ 👑 Dev : ${config.nameCreator}\n╰━━〔 ⚡ ${config.BotName} 〕━⬣\n> 🔗 Voir la chaîne : ${config.Channel}`
    }, { quoted: message });

  } catch (err) {
    console.error("Erreur muteCommand:", err.message);
    await client.sendMessage(remoteJid, {
      text: `╭━〔 🔇 𝐌𝐔𝐓𝐄 〕━⬣\n┃ ⚠️ Erreur : ${err.message}\n┃ Vérifie que le bot est *admin* !\n╰━━〔 ⚡ ${config.BotName} 〕━⬣\n> 🔗 Voir la chaîne : ${config.Channel}`
    }, { quoted: message });
  }
}
